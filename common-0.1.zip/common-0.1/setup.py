from distutils.core import setup
import sys
setup(
    name='common',
    version='0.1',
    packages=['common','common.db','common.db.dbspecial'],
    url='migenesys.com',
    license='MIGENESYS USE ONLY',
    author='vperni',
    author_email='venki.perni@migenesys.com',
    description='common microservices code'
)

