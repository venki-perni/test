import sys
print("mongodb")