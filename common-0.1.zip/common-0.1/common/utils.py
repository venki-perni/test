def sayHi():
    print("hi7878787878")